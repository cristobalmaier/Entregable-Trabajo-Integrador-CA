#!/bin/bash
if [ "$1" = "-help" ] || [ -z "$1" ] || [ -z "$2" ]; then
	echo "Uso: $0 [origen] [destino]"
	exit 0
fi

FECHA=$(date +"%Y%m%d")
B=$(basename "$1")

if [ ! -d "$1" ] || [ ! -d "$2" ]; then
	echo "ERROR: Carpetas no disponibles"
	exit 1
fi

tar -czf "$2/${B}_bkp_${FECHA}.tar.gz" -C "$(dirname "$1")" "$B"
echo "Backup Realizado"

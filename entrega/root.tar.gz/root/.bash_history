history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
vi /etc/apt/sources.list
cat /etc/apt/sources.list
vi /etc/apt/sources.list
apt update
apt full-upgrade -y
reboot
whoami
exit
apt install openssh-server -y
mkdir -p /root/.ssh
chmod 700 /root/.ssh
ls
cat Material_Adicional_TPVMCA
cd Material_Adicional_TPVMCA/
ls
..
cd ..
cat /root/Material_Adicional_TPVMCA/clave_publica.pub >> /root/.ssh/authorized_keys
cd /root/.sh/authorized_ekys
cd /root/.sh/authorized_keys
cd /root/.sh
chmod 600 /root/.ssh/authorized_keys
nano /etc/ssh/sshd_config
nano /etc/ssh
dpkg -l | grep openssh
nano /etc/ssh/sshd_config
apt update && apt install nano -y
vi /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
cat /root/Material_Adicional_TPVMCA/clave_publica.pub >> /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys
vi /etc/apt/sources.list
cat /etc/apt/sources.list
cat /etc/hosts
vi /etc/hosts
cat /etc/hosts
cat /etc/apt/sources.list
vi /etc/apt/sources.list
vi /etc/ssh/sshd_config
apt install apache2 php libapache2-mod-php -y
systemctl status apache2
cat /var/www/html/index.html
rm /var/www/html/index.html
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
chmod 644 /var/www/html/index.php 
chmod 644 /var/www/html/logo.png 
curl -I http://localhost/index.php
ip a
hostname -I
apt install mariadb-server -y
systemctl status mariadb
mysql < /root/Material_Adicional_TPVMCA/db.sql
mysql -e "SHOW DATABASES;"
curl -I http://localhost/index.php
tail -n 20 /var/log/apache2/error.log
apt install php-mysql -y
systemctl restart apache2
curl -I http://localhost/index.php
mysql -e "SHOW DATABASES;"
USE ingenieria
USE ingenieria;
mysql -u root -p
mysql -u root -p
poweroff
lsblk
fdisk /dev/sdc
lsbkl
lsblk
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
cp /var/www/html/index.php /www_dir/
cp /var/www/html/logo.png /www_dir/
chmod 644 /www_dir/index.php 
chmod 644 /www_dir/logo.png 
vi /etc/apache2/sites-available/000-default.conf 
vi /etc/apache2/apache2.conf
nano /etc/apache2/apache2.conf
nano /etc/apache2/apache2.conf
vi /etc/apache2/apache2.conf
systemctl restart apache2
curl -I http://localhost/index.php
chmod 755 /www_dir
chmod 644 /www_dir/logo.png 
chmod 644 /www_dir/index.php 
curl -I http://localhost/index.php
chown -R www-data:www-data /www_dir
vi /etc/apache2/apache2.conf
curl -I http://localhost/index.php
vi /etc/apache2/sites-available/000-default.conf 
systemctl restart apache2
curl -I http://localhost/index.php
vi /etc/fstab
cat /proc/partitions > /opt/particion
cat /opt/particion
poweroff
